package com.example.projectuts.projectuts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
